/**
 * Kadobabacloud GPS - Admin Paneli Sunucusu
 *
 * SIFIR BAĞIMLILIK: yalnızca Node.js'in yerleşik modüllerini kullanır.
 * Kurulum gerekmez → sadece "node server.js" ile çalışır.
 *
 * - Telefonlardaki uygulama konumları POST /api/location ile buraya gelir.
 * - Panele admin / 12345 ile giriş yapılır (aşağıdan değiştirilebilir).
 * - Giriş sonrası cihazlar haritada canlı görünür.
 * - Veriler data/devices.json dosyasında tutulur (harici veritabanı yok).
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ---------- AYARLAR ----------
const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || '12345';   // <-- Şifreyi buradan değiştir
// Uygulama içi admin panelinin sunucudan veri çekerken kullandığı anahtar.
// Uygulamadaki AdminActivity'de de aynısı yazılı olmalı.
const API_KEY = process.env.API_KEY || 'kadobabacloud-key';
const MAX_HISTORY = 500;      // Cihaz başına saklanacak en fazla konum sayısı
const SESSION_TTL = 1000 * 60 * 60 * 12; // 12 saat
// -----------------------------

const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'devices.json');

// Veri deposu: { deviceId: { label, last:{...}, history:[...] } }
let devices = {};
// Oturumlar: token -> expiry (ms)
const sessions = new Map();

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) devices = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (e) { console.error('Veri okunamadı:', e.message); devices = {}; }
}
let saveTimer = null;
function saveDataSoon() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(DATA_FILE, JSON.stringify(devices));
    } catch (e) { console.error('Veri yazılamadı:', e.message); }
  }, 1000);
}
loadData();

// ---------- Yardımcılar ----------
function send(res, code, body, headers = {}) {
  // CORS: uygulama içi panel (WebView, file:// kaynağı) verilere erişebilsin
  const base = {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*'
  };
  res.writeHead(code, Object.assign(base, headers));
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}

function readJsonBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (data.length > 65536) { req.destroy(); resolve(null); } // 64KB sınırı
    });
    req.on('end', () => { try { resolve(JSON.parse(data || '{}')); } catch { resolve(null); } });
    req.on('error', () => resolve(null));
  });
}

function parseCookies(req) {
  const out = {};
  const h = req.headers.cookie;
  if (!h) return out;
  h.split(';').forEach(p => {
    const i = p.indexOf('=');
    if (i > -1) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}

function isAuthed(req) {
  const sid = parseCookies(req).sid;
  if (!sid) return false;
  const exp = sessions.get(sid);
  if (!exp) return false;
  if (Date.now() > exp) { sessions.delete(sid); return false; }
  return true;
}

function serveStatic(res, file) {
  const full = path.join(PUBLIC_DIR, file);
  fs.readFile(full, (err, buf) => {
    if (err) return send(res, 404, 'Not found', { 'Content-Type': 'text/plain' });
    const ext = path.extname(full);
    const type = ext === '.html' ? 'text/html; charset=utf-8'
      : ext === '.css' ? 'text/css' : ext === '.js' ? 'application/javascript' : 'text/plain';
    res.writeHead(200, { 'Content-Type': type });
    res.end(buf);
  });
}

// Periyodik oturum temizliği
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of sessions) if (now > v) sessions.delete(k);
}, 60000);

// ---------- Sunucu ----------
const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  const method = req.method;
  const pathName = u.pathname;

  // --- Cihazdan konum alımı (uygulama buraya POST eder) ---
  if (method === 'POST' && pathName === '/api/location') {
    const b = await readJsonBody(req);
    if (!b || typeof b.lat !== 'number' || typeof b.lng !== 'number' || !b.deviceId) {
      return send(res, 400, { error: 'eksik veri' });
    }
    const id = String(b.deviceId).trim();
    const point = {
      lat: b.lat, lng: b.lng,
      accuracy: b.accuracy ?? null, speed: b.speed ?? null,
      altitude: b.altitude ?? null, battery: b.battery ?? null,
      time: b.time || Date.now()
    };
    if (!devices[id]) devices[id] = { label: b.label || id, last: null, history: [] };
    if (b.label) devices[id].label = b.label;
    devices[id].last = point;
    devices[id].history.push(point);
    if (devices[id].history.length > MAX_HISTORY)
      devices[id].history = devices[id].history.slice(-MAX_HISTORY);
    saveDataSoon();
    return send(res, 200, { ok: true });
  }

  // --- Giriş ---
  if (method === 'POST' && pathName === '/login') {
    const b = await readJsonBody(req);
    if (b && b.username === ADMIN_USER && b.password === ADMIN_PASS) {
      const token = crypto.randomBytes(24).toString('hex');
      sessions.set(token, Date.now() + SESSION_TTL);
      return send(res, 200, { ok: true }, {
        'Set-Cookie': `sid=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${SESSION_TTL / 1000}`
      });
    }
    return send(res, 401, { error: 'Kullanıcı adı veya şifre hatalı' });
  }

  // --- Çıkış ---
  if (method === 'POST' && pathName === '/logout') {
    const sid = parseCookies(req).sid;
    if (sid) sessions.delete(sid);
    return send(res, 200, { ok: true }, {
      'Set-Cookie': 'sid=; HttpOnly; Path=/; Max-Age=0'
    });
  }

  // --- Giriş sayfası (herkese açık) ---
  if (method === 'GET' && pathName === '/login') return serveStatic(res, 'login.html');

  // Uygulama içi panel için CORS ön-kontrolü (OPTIONS)
  if (method === 'OPTIONS') {
    return send(res, 204, '', {
      'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
  }

  // --- Buradan sonrası yetki ister ---
  // Erişim: ya tarayıcı oturumu (admin/12345) ya da ?key=API_KEY (uygulama içi panel)
  const keyOk = u.searchParams.get('key') === API_KEY;
  if (pathName === '/' || pathName.startsWith('/api/')) {
    if (!isAuthed(req) && !keyOk) {
      if (pathName.startsWith('/api/')) return send(res, 401, { error: 'yetkisiz' });
      res.writeHead(302, { Location: '/login' });
      return res.end();
    }
  }

  // --- Cihaz listesi ---
  if (method === 'GET' && pathName === '/api/devices') {
    const list = Object.entries(devices).map(([id, d]) => ({ id, label: d.label, last: d.last }));
    return send(res, 200, list);
  }

  // --- Cihaz geçmişi ---
  const histMatch = pathName.match(/^\/api\/devices\/([^/]+)\/history$/);
  if (method === 'GET' && histMatch) {
    const d = devices[decodeURIComponent(histMatch[1])];
    if (!d) return send(res, 404, { error: 'cihaz yok' });
    return send(res, 200, d.history);
  }

  // --- Cihaz silme ---
  const delMatch = pathName.match(/^\/api\/devices\/([^/]+)$/);
  if (method === 'DELETE' && delMatch) {
    delete devices[decodeURIComponent(delMatch[1])];
    saveDataSoon();
    return send(res, 200, { ok: true });
  }

  // --- Panel ---
  if (method === 'GET' && pathName === '/') return serveStatic(res, 'dashboard.html');

  send(res, 404, 'Not found', { 'Content-Type': 'text/plain' });
});

server.listen(PORT, () => {
  console.log(`Kadobabacloud GPS paneli çalışıyor: http://localhost:${PORT}`);
  console.log(`Giriş: ${ADMIN_USER} / ${ADMIN_PASS}`);
});
