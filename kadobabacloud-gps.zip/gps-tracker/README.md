# Kadobabacloud GPS

Arka planda sürekli çalışan, pili minimal harcayan bir **Android konum takip uygulaması** +
cihazları haritada canlı gösteren bir **admin paneli**.

- 📱 **Uygulama:** Telefonda arka planda çalışır (kapatsan bile), konumu panele gönderir.
- 🖥️ **Panel:** `admin / 12345` ile giriş yapılır, izin verdiğin cihazlar haritada görünür.

> **Önemli / Yasal:** Bu sistemi yalnızca **sana ait** ya da **takip için açık izin aldığın**
> cihazlarda kullan. Birini bilgisi/rızası olmadan takip etmek çoğu ülkede suçtur.
> Uygulama çalışırken telefonda kalıcı bir bildirim gösterir (Android bunu zaten zorunlu kılar).

---

## 📦 Paketin içinde ne var?

```
gps-tracker/
├── app/                      → Android uygulaması (kaynak kod)
├── gradle/ gradlew ...       → Derleme için hazır Gradle wrapper
├── .github/workflows/        → GitHub'da otomatik APK üretimi
└── server/                   → Admin paneli (Node.js, sıfır bağımlılık)
    ├── server.js
    └── public/ (login + harita)
```

---

## 1) APK'yı Elde Etme

APK dosyasını iki yoldan üretebilirsin. **En kolayı A yolu.**

### A Yolu — GitHub ile otomatik (bilgisayara hiçbir şey kurmadan) ✅

1. Bir [GitHub](https://github.com) hesabı aç (ücretsiz).
2. Yeni bir **repository** oluştur (ör. `kadobabacloud-gps`).
3. Bu klasördeki tüm dosyaları o repoya yükle
   (GitHub sitesinde "Add file → Upload files" ile sürükle-bırak yeterli).
4. Repoda üstteki **Actions** sekmesine gir → soldaki **"APK Derle"** iş akışını seç →
   **"Run workflow"** butonuna bas.
5. 2-3 dakika sonra iş yeşil tik alır. İşin içine girip en alttaki
   **Artifacts → `kadobabacloud-gps-apk`** dosyasını indir.
6. Zip'in içinden `app-debug.apk` çıkar. İşte APK'n bu. 🎉

### B Yolu — Android Studio ile (bilgisayarda)

1. [Android Studio](https://developer.android.com/studio) kur.
2. **Open** → bu `gps-tracker` klasörünü aç. (İlk açılışta kütüphaneleri indirir.)
3. Üst menü: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Biten APK: `app/build/outputs/apk/debug/app-debug.apk`.

---

## 2) Telefona Kurma

1. `app-debug.apk` dosyasını telefona at (kablo, WhatsApp, Drive, e-posta…).
2. Telefonda dosyaya dokun → **"Bilinmeyen kaynaklara izin ver"** çıkarsa onayla.
3. Kurulumdan sonra **Kadobabacloud GPS** uygulamasını aç.

---

## 3) Admin Panelini Çalıştırma

Panelin, telefonun internetten ulaşabileceği bir yerde çalışması gerekir.

### Bilgisayarında denemek için
```bash
cd server
node server.js
```
Tarayıcıda `http://localhost:3000` → giriş: **admin / 12345**

> Aynı ağdaki telefon için sunucu adresi: `http://BILGISAYAR_IP:3000`
> (IP'yi `ipconfig` / `ifconfig` ile öğrenirsin, ör. `http://192.168.1.20:3000`)

### Her yerden erişim için (telefon başka ağdayken)
Paneli ücretsiz bir sunucuda yayınla (Render, Railway, Fly.io, bir VPS…).
Node 18+ kurulu her yerde `node server.js` ile çalışır, **kurulum adımı yoktur**.
Yayınlayınca sana `https://seninpanelin.onrender.com` gibi bir adres verir.

---

## 4) Takibi Başlatma (takip edilecek telefonda)

1. Uygulamayı aç.
2. **Sunucu adresi** kutusuna panelin adresini yaz (ör. `http://192.168.1.20:3000`).
3. **Cihaz etiketi** ver (ör. "Babamın telefonu").
4. **Takibi Başlat**'a bas.
5. İzin isteklerinde **konum için "Her zaman izin ver"** seç (arka planda çalışması için şart).

## 4b) Cihazları Görme — Uygulama İçi Admin Paneli ✨

Cihazları tarayıcı olmadan, **doğrudan uygulamanın içinden** görebilirsin:

1. Uygulamada sunucu adresini bir kez gir (yukarıdaki gibi).
2. **📍 Admin Paneli (cihazları gör)** butonuna bas.
3. **admin / 12345** ile giriş yap.
4. İzin verdiğin tüm cihazlar haritada canlı belirir; çevrimiçi/çevrimdışı ve batarya görünür. ✅

> Tarayıcıdaki `http://sunucu:3000` paneli de aynı şekilde çalışmaya devam eder — hangisini istersen.
>
> Birden fazla telefonu tek yerden görebilmek için konumların buluştuğu bir **sunucu adresi** hâlâ
> gerekir (telefonlar birbirine doğrudan ulaşamaz). Sunucuyu kendi bilgisayarında ya da ücretsiz bir
> bulutta çalıştırabilirsin — bkz. bölüm 3.

---

## 5) Uygulamayı Kapatsan Bile Çalışması İçin (ÖNEMLİ)

Uygulama; foreground service + otomatik yeniden başlatma + açılışta başlatma ile tasarlandı.
Ama bazı markalar pil tasarrufu için arka plan uygulamalarını yine de öldürür.
Bunu engellemek için **pil optimizasyonundan muaf tut**:

- **Genel:** Ayarlar → Uygulamalar → Kadobabacloud GPS → Pil → **"Kısıtlama yok / İzin ver"**
- **Xiaomi/Redmi:** Ayarlar → Uygulamalar → İzinler → **Otomatik başlatma** aç; ayrıca
  son uygulamalarda uygulamayı aşağı çekip **kilit** simgesine bas.
- **Samsung:** Ayarlar → Pil → Arka plan kullanım sınırları → **"Uyutulmayacak uygulamalar"**a ekle.
- **Huawei/Honor:** Ayarlar → Pil → Uygulama başlatma → Kadobabacloud GPS → **Elle yönet** (hepsini aç).
- **Oppo/Realme/Vivo:** Pil ayarlarında **arka plan** ve **otomatik başlatma** izinlerini aç.

---

## 6) Şifreyi Değiştirme

`server/server.js` dosyasının başındaki satırları düzenle:
```js
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || '12345';   // <-- buraya yeni şifre
```
Ya da sunucuyu başlatırken ortam değişkeniyle ver:
```bash
ADMIN_USER=patron ADMIN_PASS=GucluSifre123 node server.js
```

> `12345` zayıf bir şifredir; paneli internete açacaksan mutlaka değiştir.

### Uygulama içi panelin şifresi ve anahtarı

Uygulama içi panel iki değeri kullanır; ikisi de
`app/src/main/java/com/example/gpstracker/AdminActivity.java` dosyasının başındadır:

```java
private static final String API_KEY   = "kadobabacloud-key"; // server.js'teki API_KEY ile AYNI olmalı
private static final String PANEL_USER = "admin";
private static final String PANEL_PASS = "12345";            // uygulama içi panel şifresi
```

`API_KEY`'i değiştirirsen `server.js` içindeki `API_KEY` değerini de aynı yap, yoksa panel sunucudan
veri çekemez.

---

## Pil / Hassasiyet Ayarları

`app/src/main/java/com/example/gpstracker/LocationService.java` içinde:

| Ayar | Varsayılan | Açıklama |
|------|-----------|----------|
| `UPDATE_INTERVAL_MS` | 30 sn | Konum güncelleme aralığı. Büyüt → daha az pil. |
| `MIN_DISPLACEMENT_M` | 10 m | Bu kadar hareket olmadan güncelleme alınmaz. |
| `PRIORITY_BALANCED_POWER_ACCURACY` | — | GPS yerine ağ/WiFi de kullanır, pil dostu. Daha hassas için `PRIORITY_HIGH_ACCURACY`. |

Daha uzun aralık + dengeli öncelik = daha uzun pil ömrü.

---

## Teknik Özet

- **Dil:** Java (Android), Node.js (panel)
- **Konum:** FusedLocationProvider (Google Play Services), pil dengeli öncelik
- **Arka plan:** Foreground service + `START_STICKY` + boot receiver
- **Çevrimdışı:** Konumlar yerel `locations.log` dosyasına da yazılır (veri kaybı olmaz)
- **Panel:** Harici bağımlılık yok, harita için Leaflet + OpenStreetMap (ücretsiz, anahtarsız)
- **minSdk:** 26 (Android 8.0) — **targetSdk:** 34 (Android 14)
