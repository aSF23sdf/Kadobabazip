package com.example.gpstracker;

/** SharedPreferences anahtar sabitleri. */
public final class Prefs {
    public static final String NAME = "kadobabacloud_prefs";
    public static final String SERVER_URL = "server_url";
    public static final String DEVICE_ID = "device_id";
    public static final String DEVICE_LABEL = "device_label";

    private Prefs() {}
}
