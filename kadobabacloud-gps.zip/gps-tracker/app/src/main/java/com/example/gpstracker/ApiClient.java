package com.example.gpstracker;

import android.util.Log;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Konum verisini admin paneli sunucusuna gönderen basit HTTP istemcisi.
 * Harici kütüphane kullanmaz (HttpURLConnection). Yüklemeler arka plan
 * thread'inde yapılır ki konum callback'i bloklanmasın.
 */
public class ApiClient {

    private static final String TAG = "ApiClient";
    private final String serverUrl;   // ör: https://panel.example.com
    private final String deviceId;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public ApiClient(String serverUrl, String deviceId) {
        this.serverUrl = serverUrl == null ? "" : serverUrl.trim();
        this.deviceId = deviceId;
    }

    public void uploadAsync(double lat, double lng, float accuracy,
                            float speed, double altitude, int battery, long time) {
        if (serverUrl.isEmpty()) {
            Log.w(TAG, "Sunucu adresi ayarlanmamış, gönderim atlandı.");
            return;
        }
        executor.execute(() -> upload(lat, lng, accuracy, speed, altitude, battery, time));
    }

    private void upload(double lat, double lng, float accuracy,
                        float speed, double altitude, int battery, long time) {
        HttpURLConnection conn = null;
        try {
            JSONObject body = new JSONObject();
            body.put("deviceId", deviceId);
            body.put("lat", lat);
            body.put("lng", lng);
            body.put("accuracy", accuracy);
            body.put("speed", speed);
            body.put("altitude", altitude);
            body.put("battery", battery);
            body.put("time", time);

            URL url = new URL(serverUrl.replaceAll("/+$", "") + "/api/location");
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(10_000);
            conn.setReadTimeout(10_000);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            byte[] out = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(out);
            }

            int code = conn.getResponseCode();
            Log.d(TAG, "Sunucu yanıtı: " + code);
        } catch (Exception e) {
            // Ağ hatasında sessizce geç; veri yerel kuyrukta duruyor.
            Log.w(TAG, "Gönderim hatası: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    public void shutdown() {
        executor.shutdown();
    }
}
